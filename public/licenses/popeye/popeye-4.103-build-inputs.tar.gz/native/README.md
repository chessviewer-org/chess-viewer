# Local native build inputs

Build inputs for the engines shipped in `public/wasm/`. Keep this directory
locally; it is not tracked or served. A copy of the build inputs is published as
`public/licenses/popeye/popeye-4.103-build-inputs.tar.gz` with the corresponding
WebAssembly engine.

- `popeye/build.sh` builds Popeye with Emscripten 6.0.13 from a clean upstream checkout
  or the extracted matching upstream source archive
  and writes the runtime to `public/wasm/popeye/` and the license set to
  `public/licenses/popeye/`.
- `popeye/patches/` and `popeye/position-preview.h` are ChessViewer's modifications to
  upstream.
- The complete matching upstream source archive is distributed at
  `public/licenses/popeye/popeye-4.103-source.tar.gz`.
- Stockfish is consumed as the unmodified `stockfish` npm release; see
  `public/licenses/stockfish/NOTICE.txt`.
